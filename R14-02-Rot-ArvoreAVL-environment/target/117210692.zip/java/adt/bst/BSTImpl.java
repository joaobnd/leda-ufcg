package adt.bst;
import java.util.List;
import java.util.ArrayList;


public class BSTImpl<T extends Comparable<T>> implements BST<T> {

	protected BSTNode<T> root;

	public BSTImpl() {
		root = new BSTNode<T>();
	}

	public BSTNode<T> getRoot() {
		return this.root;
	}

	
	public boolean isEmpty() {
		return root.isEmpty();
	}

	
	public int height() {

		return heightRec(this.root, -1);
	}

	protected int heightRec(BSTNode<T> node, int currentHeight) {

		if (!node.isEmpty()) {
			int left = heightRec((BSTNode<T>) node.getLeft(), currentHeight + 1);
			int right = heightRec((BSTNode<T>) node.getRight(), currentHeight + 1);

			currentHeight = Math.max(left, right);
		}
		return currentHeight;
	}



	public BSTNode<T> search(T element) {
		if (!isEmpty()) {
			return searchRec(this.root, element);
		} else
			return new BSTNode<T>();
	}

	private BSTNode<T> searchRec(BSTNode<T> node, T element) {

		BSTNode<T> nodeResult;

		if (node.isEmpty())
			nodeResult = new BSTNode<T>();

		else if (element.compareTo(node.getData()) == 0)
			nodeResult = node;
		else if (element.compareTo(node.getData()) > 0)
			nodeResult = searchRec((BSTNode<T>) node.getRight(), element);
		else
			nodeResult = searchRec((BSTNode<T>) node.getLeft(), element);

		return nodeResult;
	}

	
	public void insert(T element) {
		insertRec(this.root, element);
	}

	protected void insertRec(BSTNode<T> node, T element) {
		if (node.isEmpty()) {
			node.setData(element);
			node.setLeft(new BSTNode<T>());
			node.setRight(new BSTNode<T>());
			node.getLeft().setParent(node);
			node.getRight().setParent(node);
		} else {
			if (element.compareTo(node.getData()) > 0)
				insertRec((BSTNode<T>) node.getRight(), element);

			else if (element.compareTo(node.getData()) < 0)
				insertRec((BSTNode<T>) node.getLeft(), element);
		}
	}


	public BSTNode<T> maximum() {
		if (isEmpty())
			return null;
		else
			return maximumRec(this.root);
	}

	private BSTNode<T> maximumRec(BSTNode<T> node) {
		if (!node.getRight().isEmpty()) {
			return maximumRec((BSTNode<T>) node.getRight());
		} else
			return node;
	}

	
	public BSTNode<T> minimum() {
		if (isEmpty())
			return null;
		else
			return minimumRec(this.root);
	}

	private BSTNode<T> minimumRec(BSTNode<T> node) {
		if (!node.getLeft().isEmpty()) {
			return minimumRec((BSTNode<T>) node.getLeft());
		} else
			return node;
	}

	
	public BSTNode<T> sucessor(T element) {

		BSTNode<T> node = this.search(element);
		if (!node.isEmpty()) {
			if (!node.getRight().isEmpty())
				return minimumRec((BSTNode<T>) node.getRight());
			else {
				BSTNode<T> parentNode = (BSTNode<T>) node.getParent();

				while (parentNode != null && parentNode.getData().compareTo(node.getData()) < 0) {
					node = parentNode;
					parentNode = (BSTNode<T>) node.getParent();
				}
				return parentNode;
			}
		}
		return null;
	}

	
	public BSTNode<T> predecessor(T element) {

		BSTNode<T> node = this.search(element);
		if (!node.isEmpty()) {
			if (!node.getLeft().isEmpty())
				return maximumRec((BSTNode<T>) node.getLeft());
			else {
				BSTNode<T> parentNode = (BSTNode<T>) node.getParent();

				while (parentNode != null && parentNode.getData().compareTo(node.getData()) > 0) {
					node = parentNode;
					parentNode = (BSTNode<T>) node.getParent();
				}
				return parentNode;
			}
		}
		return null;
	}

	public void remove(T element) {
		BSTNode<T> node = search(element);
		if ((!node.isEmpty()) && (element != null)) {
			remove(node);
		}
	}

	protected BSTNode<T> remove(BSTNode<T> node) {
		if (node.getRight().isEmpty() && node.getLeft().isEmpty()) {
			node.setData(null);
			node.setLeft(null);
			node.setRight(null);
		} else if (node.getRight().isEmpty()) {
			node.setData(node.getLeft().getData());
			node.setRight(node.getLeft().getRight());
			node.setLeft(node.getLeft().getLeft());
			node.getRight().setParent(node);
			node.getLeft().setParent(node);
		} else if (node.getLeft().isEmpty()) {
			node.setData(node.getRight().getData());
			node.setLeft(node.getRight().getLeft());
			node.setRight(node.getRight().getRight());
			node.getRight().setParent(node);
			node.getLeft().setParent(node);
		} else {
			T value = node.getData();
			BSTNode<T> sucessor = sucessor(value);
			node.setData(sucessor.getData());
			sucessor.setData(value);
			remove((BSTNode<T>) sucessor);
		}
		
		return node;
	}

	
	public T[] preOrder() {

		@SuppressWarnings("unchecked")
		T[] arrayResult = (T[]) new Comparable[this.size()];
		List<T> aux = new ArrayList<T>();

		if (!this.isEmpty()) {
			preOrderRec(this.root, aux);

			aux.toArray(arrayResult);
		}
		return arrayResult;
	}

	private void preOrderRec(BSTNode<T> node, List<T> array) {

		if (!node.isEmpty()) {
			array.add(node.getData());
			preOrderRec((BSTNode<T>) node.getLeft(), array);
			preOrderRec((BSTNode<T>) node.getRight(), array);
		}
	}

	
	public T[] order() {

		@SuppressWarnings("unchecked")
		T[] arrayResult = (T[]) new Comparable[this.size()];
		List<T> aux = new ArrayList<T>();

		if (!this.isEmpty()) {
			OrderRec(this.root, aux);

			aux.toArray(arrayResult);
		}
		return arrayResult;
	}

	private void OrderRec(BSTNode<T> node, List<T> array) {

		if (!node.isEmpty()) {
			OrderRec((BSTNode<T>) node.getLeft(), array);
			array.add(node.getData());
			OrderRec((BSTNode<T>) node.getRight(), array);
		}
	}


	public T[] postOrder() {

		@SuppressWarnings("unchecked")
		T[] arrayResult = (T[]) new Comparable[this.size()];
		List<T> aux = new ArrayList<T>();

		if (!this.isEmpty()) {
			postOrderRec(this.root, aux);

			aux.toArray(arrayResult);
		}
		return arrayResult;
	}

	private void postOrderRec(BSTNode<T> node, List<T> array) {

		if (!node.isEmpty()) {
			postOrderRec((BSTNode<T>) node.getLeft(), array);
			postOrderRec((BSTNode<T>) node.getRight(), array);
			array.add(node.getData());
		}
	}

	/**
	 * This method is already implemented using recursion. You must understand how
	 * it work and use similar idea with the other methods.
	 */
	
	public int size() {
		return size(this.root);
	}

	private int size(BSTNode<T> node) {
		int result = 0;
		// base case means doing nothing (return 0)
		if (!node.isEmpty()) { // indusctive case
			result = 1 + size((BSTNode<T>) node.getLeft()) + size((BSTNode<T>) node.getRight());
		}
		return result;
	}

}